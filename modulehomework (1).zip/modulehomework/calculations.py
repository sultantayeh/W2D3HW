import math

def calculate_square_footage(length, width):
    return length * width

def calculate_circumference(radius):
    return 2 * math.pi * radius
